import java.util.*;

public class Ass1
{
    public static void main(String[] args)
    {
        Ass1 t= new Ass1();
        System.out.println("This is Assignment-1, dated: 14/01/21");
        System.out.println("This is question-1.");
        t.display();
        System.out.println();
        System.out.println("This is question-2");
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter 1.square      2.rectangle     3.circle        4.triangle");
        int ch= sc.nextInt();
        double res;
        switch (ch) 
        {
            case 1:
                System.out.println("Enter side of square:");
                double si= sc.nextDouble();
                res= t.ratio_square(si);
                t.disp(res);
                break;
            case 2:
                System.out.println("Enter length and breadth of rectangle respectively:");
                double lt= sc.nextDouble();
                double ht= sc.nextDouble();
                res= t.ratio_rectangle(lt, ht);
                t.disp(res);
                break;
            case 3:
                System.out.println("Enter radius of circle:");
                double r= sc.nextDouble();
                res= t.ratio_circle(r);
                t.disp(res);
                break;
            case 4:
                System.out.println("Enter side of equilateral triangle:");
                double bs= sc.nextDouble();
                res= t.ratio_eqil_triangle(bs);
                t.disp(res);
                break;
            default:
                break;
        }
        System.out.println();
    }

    public void display()
    {
        System.out.println("Welcome to Ass1.display().");
    }
    public double ratio_square(double s)
    {
        double area= s*s;
        double peri= 4*s;
        System.out.println("The value of area is to perimeter of square is : "+(area/peri));
        return (area/peri);
    }
    public double ratio_rectangle(double l, double b) 
    {
        double area = l*b;
        double peri = 2*(l+b);
        System.out.println("The value of area is to perimeter of square is : " + (area / peri));
        return (area / peri);
    }
    public double ratio_circle(double rd) 
    {
        double area = rd*rd;
        double peri = (6.28)*rd;
        System.out.println("The value of area is to perimeter of square is : " + (area / peri));
        return (area / peri);
    }
    public double ratio_eqil_triangle(double b) 
    {
        double area = (0.43)*b*b;
        double peri = 3*b;
        System.out.println("The value of area is to perimeter of square is : " + (area / peri));
        return (area / peri);
    }

    public void disp(double val)
    {
        System.out.println("This is for question-3 : " + val);
    }
} 